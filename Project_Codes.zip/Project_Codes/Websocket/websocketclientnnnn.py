import asyncio
import json
import string
import websockets
import ssl
import random
import time


async def connect(use_ssl=False):
    uri = "ws://192.168.1.90:8765"  # Use 'ws' for non-secure WebSocket
    if use_ssl:
        uri = "wss://192.168.1.90:8765"  # Use 'wss' for secure WebSocket

    return await websockets.connect(uri, ssl=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT) if use_ssl else None)


async def send_message(websocket, message):
    await websocket.send(message)


async def receive_message(websocket):
    response = await websocket.recv()
    return response


def generate_iot_data(size):
    timestamp = time.time()

    size_mb = size / 1024.0

    # Generate random string data to match the specified size
    random_data = ''.join(random.choices(string.ascii_letters + string.digits, k=int(size * 1024)))

    if size_mb >= 1:
        size_unit = 'MB'
        size_str = f'{size_mb:.2f}'
    else:
        size_unit = 'KB'
        size_str = str(int(size))

    iot_data = {
        'timestamp': timestamp,
        'temperature': random.uniform(20.0, 30.0),
        'humidity': random.uniform(40.0, 60.0),
        'pressure': random.uniform(1000.0, 1010.0),
        'random_data': random_data,
        'size': size_str + size_unit  # Convert size to string before concatenation
    }
    return json.dumps(iot_data).encode('utf-8')


def save_iot_data_to_file(size, filename):
    timestamp = time.time()

    size_mb = size / 1024.0

    # Generate random string data to match the specified size
    random_data = ''.join(random.choices(string.ascii_letters + string.digits, k=int(size * 1024)))

    if size_mb >= 1:
        size_unit = 'MB'
        size_str = f'{size_mb:.2f}'
    else:
        size_unit = 'KB'
        size_str = str(int(size))

    iot_data = {
        'timestamp': timestamp,
        'temperature': random.uniform(20.0, 30.0),
        'humidity': random.uniform(40.0, 60.0),
        'pressure': random.uniform(1000.0, 1010.0),
        'random_data': random_data,
        'size': size_str + size_unit  # Convert size to string before concatenation
    }

    json_data = json.dumps(iot_data).encode('utf-8')

    with open(filename, 'wb') as file:
        file.write(json_data)


# Add this
send_file = True  # Set to True to send a file, or False to generate and send a message
iotfile = "received_websocket_data.json"


def random_delay():
    return random.uniform(0.1, 0.5)  # Add a random delay between 0.1 and 0.5 seconds


def readfile(size, file):
    save_iot_data_to_file(size, file)
    with open(file, 'rb') as file:
        data_to_send = file.read()
    return data_to_send


async def main(use_ssl=False, file_path=True):
    data_to_send = ""
    uri = "ws://192.168.1.90:8765"  # Use 'ws' for non-secure WebSocket
    if use_ssl:
        uri = "wss://192.168.1.90:8765"  # Use 'wss' for secure WebSocket
    async with websockets.connect(uri, ssl=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT) if use_ssl else None) as websocket:
        current_size_kb = 1  # Starting size in KB
        max_size_kb = 20048  # Maximum allowed size in KB (20 MB)
        while current_size_kb <= max_size_kb:

            if file_path:
                data_to_send = readfile(current_size_kb, iotfile)
            else:
                data_to_send = generate_iot_data(current_size_kb)

            await send_message(websocket, data_to_send)
            # response = await receive_message(websocket)
            print(data_to_send)
            print()

            # Add a random delay to make messages less predictable
            delay = random_delay()
            time.sleep(delay)

            # Increment the size gradually
            current_size_kb *= 2  # Double the size


if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(main())
