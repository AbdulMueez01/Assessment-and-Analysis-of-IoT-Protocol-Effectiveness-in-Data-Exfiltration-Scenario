import asyncio
import json
import websockets
import ssl
import time
import random

# Variables for latency, throughput, and stealth calculations
last_receive_time = time.time()
total_received_bytes = 0
last_message_time = time.time()
longest_silence = 0
total_messages = 0
total_silence = 0

def append_to_received_data_file(received_data, latency, overhead, throughput, silence_duration,
                                 filename='received_websocket_data.txt'):
    with open(filename, 'a', encoding='utf-8') as file:
        file.write(f"Message size '{received_data['size']}'\n")
        file.write(f"Latency: {latency:.4f} seconds\n")
        file.write(f"Overhead: {overhead:.4f} seconds\n")
        file.write(f"Throughput: {throughput:.4f} bytes per second\n")
        file.write(f"Stealth: Delayed by {silence_duration:.4f} seconds\n")
        file.write('\n')


async def handle_client(websocket, path):
    global last_receive_time, total_received_bytes, last_message_time, longest_silence, total_messages, total_silence

    while True:
        message = await websocket.recv()
        try:
            received_data = json.loads(message.decode('utf-8'))
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return  # Skip processing if JSON decoding fails

        current_time = time.time()

        # Extract timestamp from the message
        timestamp = float(received_data['timestamp'])

        # Calculate latency
        latency = current_time - timestamp

        # Calculate throughput (bytes per second)
        total_received_bytes += len(received_data)
        elapsed_time = current_time - last_receive_time
        throughput = total_received_bytes / elapsed_time if elapsed_time > 0 else 0

        # Calculate overhead
        overhead = elapsed_time - latency

        # Calculate stealth metrics
        silence_duration = current_time - last_message_time
        if silence_duration > longest_silence:
            longest_silence = silence_duration

        last_message_time = current_time
        total_messages += 1
        total_silence += silence_duration

        # print the received data and metrics to the screen
        print(f"Message size '{received_data['size']}'\n".encode('utf-8'))
        print(f"Latency: {latency:.4f} seconds\n".encode('utf-8'))
        print(f"Overhead: {overhead:.4f} seconds\n".encode('utf-8'))
        print(f"Throughput: {throughput:.4f} bytes per second\n".encode('utf-8'))
        print(f"Stealth: Delayed by {silence_duration:.4f} seconds\n".encode('utf-8'))
        print(b'\n')

        append_to_received_data_file(received_data, latency, overhead, throughput, silence_duration)

        #response = f"Received: {received_data}"
        #await websocket.send(response)


async def start_websocket_server(use_ssl=False):
    # Conditionally set the SSL context based on use_ssl
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER) if use_ssl else None

    # Use websockets.serve instead of websocket.serve
    start_server = await websockets.serve(
        handle_client, "192.168.1,90", 8765, ssl=ssl_context
    )
    await start_server.wait_closed()

    # asyncio.get_event_loop().run_until_complete(start_server)
    # asyncio.get_event_loop().run_forever()


# Example usage:
# To start without SSL:
# start_websocket_server(use_ssl=False)

# To start with SSL:
# start_websocket_server(use_ssl=True)

if __name__ == "__main__":
    asyncio.run(start_websocket_server(use_ssl=False))
   