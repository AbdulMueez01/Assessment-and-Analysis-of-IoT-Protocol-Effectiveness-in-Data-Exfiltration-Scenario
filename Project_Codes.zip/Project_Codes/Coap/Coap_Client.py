import json
import string
import sys  # import sys module fo system related functionlity
import chiton.network.client as server #imports the chiton module server
import chiton.protocol.coap as coap #imports the chiton coap protocol
import random
import time


def random_delay():
    return random.uniform(0.1, 0.5)


def main():
    protocol = coap.CoAP()
    coap_client = client.Client(protocol, '127.0.0.1')
    current_size_kb = 1  # Starting size in KB
    max_size_kb = 20480  # Maximum allowed size in KB (2 MB)
    while current_size_kb <= max_size_kb:
        data_to_send = generate_iot_data(current_size_kb)
        coap_client.send(data_to_send)

        print(data_to_send)
        print()

        # Add a random delay to make messages less predictable
        delay = random_delay()
        time.sleep(delay)

        # Increment the size gradually
        current_size_kb *= 2  # Double the size


def read_data_from_file():
    file_name = "rb.txt"
    try:
        with open(file_name, 'r') as file:
            # Assuming the file contains JSON-formatted data
            data = file.read()
            return data
    except FileNotFoundError:
        print(f"File {file_name} not found.")
        return generate_iot_data()  # If file not found, generate data as a fallback


def generate_iot_data(size):
    timestamp = time.time()

    size_mb = size / 1024.0

    # Generate random string data to match the specified size
    random_data = ''.join(random.choices(string.ascii_letters + string.digits, k=int(size * 1024)))

    if size_mb >= 1:
        size_unit = 'MB'
        size_str = f'{size_mb:.2f}'
    else:
        size_unit = 'KB'
        size_str = str(int(size))

    iot_data = {
        'timestamp': timestamp,
        'temperature': random.uniform(20.0, 30.0),
        'humidity': random.uniform(40.0, 60.0),
        'pressure': random.uniform(1000.0, 1010.0),
        'random_data': random_data,
        'size': size_str + size_unit  # Convert size to string before concatenation
    }
    return json.dumps(iot_data).encode('utf-8')


if __name__ == '__main__':
    main()


