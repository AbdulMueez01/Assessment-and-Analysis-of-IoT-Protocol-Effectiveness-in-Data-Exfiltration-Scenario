import paho.mqtt.client as mqtt
import json
import time

# MQTT broker information
broker_address = "broker.hivemq.com"
broker_port = 1883
mqtt_topic = "my_topic"

# Variables for tracking message metrics
last_receive_time = time.time()
total_received_bytes = 0
last_message_time = time.time()
longest_silence = 0
total_messages = 0
total_silence = 0

# File to store received data and metrics
data_filename = "received_mqttdata.txt"
data_file = open(data_filename, 'ab')


def on_connect(client, userdata, flags, rc):
    # Callback function when connected to the MQTT broker
    print("Connected with result code " + str(rc))
    # Subscribe to the specified MQTT topic upon connection
    client.subscribe(mqtt_topic)


def on_message(client, userdata, message):
    # Callback function when a message is received from the MQTT broker
    global last_receive_time, total_received_bytes, last_message_time, longest_silence, total_messages, total_silence

    try:
        # Attempt to decode the payload as JSON
        received_mqttdata = json.loads(message.payload.decode('utf-8'))
    except json.JSONDecodeError as e:
        # Skip processing if JSON decoding fails
        print(f"Error decoding JSON: {e}")
        return

    current_time = time.time()

    # Extract timestamp from the message
    timestamp = float(received_mqttdata['timestamp'])

    # Calculate latency
    latency = current_time - timestamp

    # Calculate throughput (bytes per second)
    total_received_bytes += len(received_mqttdata)
    elapsed_time = current_time - last_receive_time
    throughput = total_received_bytes / elapsed_time

    # Calculate overhead
    overhead = elapsed_time - latency

    # Print the received data and metrics to the screen
    print(f"Received message on topic '{message.topic}'")
    print(f"Message size '{received_mqttdata['size']}'")
    print(f"Latency: {latency:.4f} seconds")
    print(f"Overhead: {overhead:.4f} seconds")
    print(f"Throughput: {throughput:.4f} bytes per second")
    print()

    # Write the received data and metrics to the file
    data_file.write(f"Received message on topic '{message.topic}'\n".encode('utf-8'))
    data_file.write(f"Message size '{received_mqttdata['size']}'\n".encode('utf-8'))
    data_file.write(f"Latency: {latency:.4f} seconds\n".encode('utf-8'))
    data_file.write(f"Overhead: {overhead:.4f} seconds\n".encode('utf-8'))
    data_file.write(f"Throughput: {throughput:.4f} bytes per second\n".encode('utf-8'))
    data_file.write(b'\n')

    last_receive_time = current_time


def main():
    # Create an MQTT client
    client = mqtt.Client()
    # Set callback functions
    client.on_connect = on_connect
    client.on_message = on_message

    # Connect to the MQTT broker
    client.connect(broker_address, broker_port, 60)
    # Start the MQTT client loop in a separate thread
    client.loop_start()

    try:
        while True:
            pass  # Keep the server running to receive messages

    except KeyboardInterrupt:
        # Handle keyboard interrupt (Ctrl+C)
        print("Connection closed.")
        # Close the data file and disconnect from the MQTT broker
        data_file.close()
        client.disconnect()
        client.loop_stop()


if __name__ == "__main__":
    # Execute the main function if the script is run directly
    main()
