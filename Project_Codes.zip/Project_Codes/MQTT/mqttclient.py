import paho.mqtt.client as mqtt
import time
import json
import random
import string

broker_address = "test.mosquitto.org"
broker_port = 1883
mqtt_topic = "my_topic"


def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    client.subscribe(mqtt_topic)


def on_message(client, userdata, message):
    # Client-side code for handling incoming messages (if needed)
    pass


def generate_iot_data(size):
    timestamp = time.time()

    size_mb = size / 1024.0

    # Generate random string data to match the specified size
    random_data = ''.join(random.choices(string.ascii_letters + string.digits, k=int(size * 1024)))

    if size_mb >= 1:
        size_unit = 'MB'
        size_str = f'{size_mb:.2f}'
    else:
        size_unit = 'KB'
        size_str = str(int(size))

    iot_data = {
        'timestamp': timestamp,
        'temperature': random.uniform(20.0, 30.0),
        'humidity': random.uniform(40.0, 60.0),
        'pressure': random.uniform(1000.0, 1010.0),
        'random_data': random_data,
        'size': size_str + size_unit  # Convert size to string before concatenation
    }
    return json.dumps(iot_data).encode('utf-8')


def random_delay():
    return random.uniform(0.1, 0.5)


def main():
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(broker_address, broker_port, 60)
    client.loop_start()

    try:
        current_size_kb = 1  # Starting size in KB
        max_size_kb = 2048  # Maximum allowed size in KB (2 MB)

        while current_size_kb <= max_size_kb:
            data_to_send = generate_iot_data(current_size_kb)
            client.publish(mqtt_topic, data_to_send)

            print(data_to_send)

            # Add a random delay to make messages less predictable
            delay = random_delay()
            time.sleep(delay)

            # Increment the size gradually
            current_size_kb *= 2  # Double the size

    except KeyboardInterrupt:
        print("Connection closed.")
        client.disconnect()
        client.loop_stop()


if __name__ == "__main__":
    main()
