import matplotlib.pyplot as plt
# Message sizes
message_sizes = ['1KB', '2KB', '4KB', '8KB', '16KB', '32KB', '64KB', '128KB', '256KB', '512KB', '1.00MB', '2.00MB', '4.00MB']

# Latency data
websocket_latency = [0.0005, 1.4895, 1.2481, 0.9905, 0.60945, 0.2431, 0.03225, 0.0349, 0.0717, 0.1744, 6.0518, 11.1122, 19.2244]
mqtt_latency = [0.2482, 0.2358, 0.2295, 0.3274, 0.4907, 0.3912, 0.5012, 0.8951, 1.2055, 1.3927, 2.6318, 4.0952, 8.0952]
coap_latency = [0.9005, 1.68695, 1.4481, 1.40905, 1.4945, 1.3431, 1.4225, 1.4349, 3.4717, 6.5744, 11.6518, 16.0952, 23.0952]
15# Overhead data
websocket_overhead = [35.51535, 35.93435, 36.10885, 36.3487, 36.74725, 37.11665, 37.3297, 37.58015, 37.8309, 38.36185, 61.6298, 122.4568, 244.9136]
mqtt_overhead = [5.9545, -0.0913, 0.1667, -0.0764, -0.1899, -0.3008, 0, -0.3113, -0.6922, -0.8145, 2.9844, 8.2342, 12.2342]
coap_overhead = [6.9545, 5.90865, 6.4481, 6.0787, 5.67935, 5.56095, 5.774, 5.52425, 5.2735, 4.63815, 18.9818, 26.7861, 30.7861]

# Throughput data
websocket_throughput = [0.9312, 1.2174, 1.5714, 1.9424, 2.3133, 2.6931, 3.0933, 3.8642, 4.12075, 4.3444, 61.6298,
                        122.4568, 244.9136]
mqtt_throughput = [2.3971, 3.0309, 5.4285, 6.639, 9.7254, 10.5075, 8.8044, 9.2163, 10.7054, 34.6503, 53.9844,
                   75.2342, 86.2342]
coap_throughput = [49.3251, 52.0309, 54.4285, 56.639, 59.7254, 55.5075, 47.8044, 45.2163, 43.7054, 37.6503, 33.9818,
                   29.7861, 26.961]

# Stealth Delay data
websocket_stealth_delay = [30.4157, 1.8904, 0.0005, 0.0005, 0.0005, 0.00155, 0.00155, 0.3005, 0.44105, 0.4658, 2.9207, 9.0271, 18.0542]
mqtt_stealth_delay = [6.4027, 0.1445, 0.3962, 0.2509, 0.3008, 0.1109, 0.5012, 0.5838, 0.7133, 1.0782, 22.1147, 29.2408, 33.2408]
coap_stealth_delay = [6.4027, 1.1445, 1.3962, 1.2509, 1.3008, 1.1109, 1.5012, 1.5838, 1.7133, 2.0782, 23.1147, 30.2408, 35.8408]

# Plot latency
plt.figure(figsize=(10, 5))
plt.plot(message_sizes, websocket_latency, marker='o', label='Websocket')
plt.plot(message_sizes, mqtt_latency, marker='o', label='MQTT')
plt.plot(message_sizes, coap_latency, marker='o', label='CoAP')
plt.title('Latency Comparison')
plt.xlabel('Message Size')
plt.ylabel('Latency (s)')
plt.legend()
plt.show()

# Plot Overhead
plt.figure(figsize=(10, 5))
plt.plot(message_sizes, websocket_overhead, marker='o', label='WebSocket')
plt.plot(message_sizes, mqtt_overhead, marker='o', label='MQTT')
plt.plot(message_sizes, coap_overhead, marker='o', label='CoAP')
plt.title('Overhead Comparison')
plt.xlabel('Message Size')
plt.ylabel('Overhead (s)')
plt.legend()
plt.show()

# Plot Throughput
plt.figure(figsize=(10, 5))
plt.plot(message_sizes, websocket_throughput, marker='o', label='WebSocket')
plt.plot(message_sizes, mqtt_throughput, marker='o', label='MQTT')
plt.plot(message_sizes, coap_throughput, marker='o', label='CoAP')
plt.title('Throughput Comparison')
plt.xlabel('Message Size')
plt.ylabel('Throughput (B/s)')
plt.legend()
plt.show()

# Plot Stealth Delay
plt.figure(figsize=(10, 5))
plt.plot(message_sizes, websocket_stealth_delay, marker='o', label='WebSocket')
plt.plot(message_sizes, mqtt_stealth_delay, marker='o', label='MQTT')
plt.plot(message_sizes, coap_stealth_delay, marker='o', label='CoAP')
plt.title('Stealth Delay Comparison')
plt.xlabel('Message Size')
plt.ylabel('Stealth Delay (s)')
plt.legend()
plt.show()
